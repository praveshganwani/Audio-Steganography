import librosa
import matplotlib.pyplot as plt
import math
import numpy as np

signal1, sr1 = librosa.load('./preamble.wav')
signal2, sr2 = librosa.load('./song_embedded.wav')

# signal1, sr1 = librosa.load('./BASS-Rani.wav')
# signal2, sr2 = librosa.load('./song_embedded.wav')

# plt.plot(signal1, label='OG', color='r')
# plt.plot(signal2, label='DIS', color='b')
# plt.show()


signal_diff = signal1 - signal2
# print(len(signal_diff))

# y = original_sig/variable which store original sig / (sqrt (mean (mean(diff^2)))
# ans = 10*np.log10(np.max(y));

sum_of_sq_of_orig=np.sum(signal1**2)
# sum_of_sq_of_steg=np.sum(signal2**2)
sum_of_sq_of_steg=np.sum(signal_diff**2)

snr = 10*np.log10(sum_of_sq_of_orig/(sum_of_sq_of_steg))

print('Sum of Sq of Orig = ', sum_of_sq_of_orig)
print('Sum of Sq of Steg = ', sum_of_sq_of_steg)
print('SNR = ', snr)



# rms_orig = math.sqrt(np.mean(signal1**2))
# rms_steg = math.sqrt(np.mean(signal2**2))


# print(rms_orig)
# print(rms_steg)

# snr2 = 10*np.log10(rms_orig**2/rms_steg**2)

# print('SNR2 = ', snr2)

