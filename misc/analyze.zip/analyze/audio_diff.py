from AudioAnalyzer import AudioAnalyzer, SpectrumCompare

original = AudioAnalyzer("preamble.wav", input_sr=22050, fft_size=22050)
remastered = AudioAnalyzer("preamble_embedded.wav", input_sr=22050, fft_size=22050)

# original.plot_spectrum(min_freq=20, max_freq=1000, title="Original")
# remastered.plot_spectrum(min_freq=20, max_freq=1000, title="Embedded")

orig_to_remastered = SpectrumCompare(original, remastered)

orig_to_remastered.plot_spectrum_group(
    frange=(20,1000), 
    title="Spectrograms - Original vs Embedded", 
    legend=("Original", "Embedded")
    )

# orig_to_remastered.plot_spectrum_group(
#     frange=(20,1000), 
#     ratio=True, 
#     threshold=True,
#     title="Spectrograms - original vs 2009 remaster (with threshold)", 
#     legend=("Original", "Remaster", "Amplitude Diff.", "Threshold")
#     )

# orig_to_remastered.plot_spectrum_heatmap(
#     frange=(20,1000), 
#     plot_spec1=False
#     )