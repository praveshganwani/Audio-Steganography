import librosa
import soundfile as sf
from scipy.io import wavfile
from pesq import pesq

sr = 16000
y, s = librosa.load('preamble.wav', sr=16000) # Downsample 22.05kHz to 16kHz
sf.write('preamble-16.wav', y, sr)

y, s = librosa.load('song_embedded.wav', sr=16000) # Downsample 22.05kHz to 16kHz
sf.write('song_embedded-16.wav', y, sr)

rate, ref = wavfile.read("preamble-16.wav")
rate, deg = wavfile.read("song_embedded-16.wav")

print(pesq(rate, ref, deg, 'wb'))
print(pesq(rate, ref, deg, 'nb'))